<article>
    <div class="row">
    <div class="col-7">
    <h1>Exercise instructions</h1>
    <h1>For all fitness levels.</h1>
    <h1>Completely free.</h1>
    <h4>Start now and get FIT today!</h4>
</p>
</div>
<div class="row">
<div class="col-5">
  test
</div>
</div>
</div>
</div>
</article>
