<!-- Navbar -->
<main class="container-expand-fg">
    <div class="navbar">
    <ul class="logo">
            <li><a href="#"><img src="img/placeholder2.png" class="logo2" ></a></li>
</ul>
<ul class="nav">
            <li> <a href="#" class="navFont"> HOME </a></li>
            <li> <a href="#" class="navFont"> INFO▼ </a></li>
            <li> <a href="#" class="navFont"> ABOUT </a></li>
            <li> <a href="#" class="navFont"> CONTACT </a></li>
            <li> <a href="#" class="navFont"> FAQ </a></li>
            </ul>
            <ul class="logo2">
            <li><a href="#" class="right"><img src="./img/placeholder-man.png" class="logo"></a></li>
</ul>
        </div>
</main>